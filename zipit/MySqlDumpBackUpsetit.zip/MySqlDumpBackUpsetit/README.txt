TÄSSÄ ON MYSQLDUMP BACKUP .BAT TYÖKALU

https://www.youtube.com/watch?v=xLOw7LeoBwo //GUIDE KOKO HOMMAAN

-------------------------------------------------------------------------------
-JOS HALUAT LAITTAA TÄMÄ OMALLE KONEELLESI NIIN SINUN PITÄÄ MUUTTAA KOHTIA
 TÄHÄN KÄY ETSIMÄSSÄ SERVERISI "BIN" FOLDERI

rem path to mysql server bin folder
cd "C:\UniServerZ\core\mysql\bin"
--------------------------------------------------------------------------------


-SEURAAVAKSI MUUTA KÄYTTÄJÄ JA SALASANA OIKEAKSI
---------------------------------------------------------------------------------------
-VIELÄ SE PAIKKA MIHIN HALUAT BACKUPPIEN MENEVÄN PITÄÄ LAITTAA
 JA MUUTA BACKUP NAME MIKSI IKINÄ HALUATKAAN

rem backup file name generation
set backup_path=C:\BACKUPS\BACKUPS1	//TÄHÄN BACKUP PAIKKA MIHIN HALUAT SEN TALLENTAA
set backup_name=PankkiAutomataBackup	//TÄHÄN NIMI MILLÄ NE TALLENNETAAN
-----------------------------------------------------------------------------------------

LOPPU SIITÄ START.BAT:ISTA ON VAIN BACKUPIN LUOMISTA SIITÄ EI TARVITSE VÄLITTÄÄ.

JOS HALUAA AJOITTAA NÄMÄ BACKUPIT NIIN Win10 työkalu "task scheduler" tai suomeksi "tehtävien ajoitus"
NIIN SIELVÄ VOI AJOITTAA KOKO HOMMAN.


