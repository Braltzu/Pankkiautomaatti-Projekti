#ifndef RFIDCARDREADERDLL_H
#define RFIDCARDREADERDLL_H

#include "rfidCardReaderDLL_global.h"
#include <QObject>
#include <QSerialPort>
#include <QSerialPortInfo>

class SerialPortReader : public QObject
{
    Q_OBJECT

public:
    explicit SerialPortReader(QObject *parent = nullptr);
    ~SerialPortReader();

    void startReading();

signals:
    void numberRead(QByteArray num);

private slots:
    void readNumber();

private:
    QSerialPort *port;
};

#endif // RFIDCARDREADERDLL_H
