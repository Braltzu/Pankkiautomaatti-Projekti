#include "pinui2.h"

Pinui2::Pinui2() {}
