#ifndef UI_H
#define UI_H

class ui
{
public:
    ui();
};

#endif // UI_H
