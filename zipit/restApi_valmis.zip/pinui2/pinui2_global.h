#ifndef PINUI2_GLOBAL_H
#define PINUI2_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(PINUI2_LIBRARY)
#define PINUI2_EXPORT Q_DECL_EXPORT
#else
#define PINUI2_EXPORT Q_DECL_IMPORT
#endif

#endif // PINUI2_GLOBAL_H
