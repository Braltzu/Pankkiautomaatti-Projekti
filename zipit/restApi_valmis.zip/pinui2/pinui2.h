#ifndef PINUI2_H
#define PINUI2_H

#include "pinui2_global.h"

class PINUI2_EXPORT Pinui2
{
public:
    Pinui2();
};

#endif // PINUI2_H
